def greet():
    print ("Always start with a greeting")
