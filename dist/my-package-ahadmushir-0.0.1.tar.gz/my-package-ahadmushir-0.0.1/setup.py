from setuptools import setup
setup(name='my-package-ahadmushir',
version='0.0.1',
description='Testing installation of Package',
url='https://github.com/ahadmushir/my_first_package',
author='ahadmushir',
author_email='a.ahad.mushir@gmail.com',
license='MIT',
packages=['mypackage'],
zip_safe=False)
