def greet():
    print ("Always start with a greeting")

def author():
    print ("ahadmushir")

