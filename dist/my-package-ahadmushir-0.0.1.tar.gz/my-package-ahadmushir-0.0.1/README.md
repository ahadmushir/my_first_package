# my_first_package
Sample dummy package for Python

To visit the pypi test package, please visit
https://test.pypi.org/project/my-package-ahadmushir/0.0.1/

or 

`pip install -i https://test.pypi.org/simple/ my-package-ahadmushir==0.0.1`


![Syntax Checker](https://github.com/ahadmushir/my_first_package/workflows/Syntax%20Checker/badge.svg?event=pull_request)
